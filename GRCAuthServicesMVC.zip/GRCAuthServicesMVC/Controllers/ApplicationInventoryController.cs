﻿using GRCAuthServicesMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GRCAuthServicesMVC.Controllers
{
    public class ApplicationInventoryController : Controller
    {
        private readonly ApplicationDbContext appDbContext;

        public ApplicationInventoryController(ApplicationDbContext appDbContext)
        {
            this.appDbContext = appDbContext;
        }


        [HttpPost]
        public async Task<IActionResult> AddInventoryAsync(Models.ApplicationInventory appInventory)
        {
            if (ModelState.IsValid)
            {

                appDbContext.ApplicationInventories.Add(appInventory);
                await appDbContext.SaveChangesAsync();

                //await appDbContext.ApplicationInventory.Add(appInventory);


                return RedirectToAction("Index");
            }

            return View(appInventory);


        }


        [HttpGet]

        public async Task<IActionResult> Index()
        {

            var domainmodel = await appDbContext.ApplicationInventories.ToListAsync();
            if (domainmodel == null)
            {
                throw new Exception("Model is null");
            }

            return View("~/Views/Home/ApplicationInventory.cshtml", domainmodel);

        }
    }
}
