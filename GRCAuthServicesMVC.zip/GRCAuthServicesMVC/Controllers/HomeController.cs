using System.Diagnostics;
using GRCAuthServicesMVC.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GRCAuthServicesMVC.Controllers
{
    public class HomeController : Controller
    {
         private readonly ApplicationDbContext appDbContext;

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext appDbContext)
        {
            _logger = logger;
            this.appDbContext = appDbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ApplicationInventory()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }



        [HttpPost]
        public async Task<IActionResult> AddInventoryAsync(Models.ApplicationInventory appInventory)
        {
            if (ModelState.IsValid)
            {

                appDbContext.ApplicationInventories.Add(appInventory);
                await appDbContext.SaveChangesAsync();

                //await appDbContext.ApplicationInventory.Add(appInventory);


                return RedirectToAction("Index");
            }

            return View(appInventory);


        }


        [HttpGet]

        public async Task<IActionResult> GetAll()
        {

            var domainmodel = await appDbContext.ApplicationInventories.ToListAsync();
            if (domainmodel == null)
            {
                throw new Exception("Model is null");
            }

            return View("~/Views/Home/ApplicationInventory.cshtml", domainmodel);

        }






        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
